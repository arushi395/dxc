package com.dxc.training.dao;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;
import com.dxc.training.dbcon.DBConnection;
import com.dxc.training.model.Training;
public class TrainingDAOImpl implements TrainingDAO{
	Connection connection=DBConnection.getConnection();
	Scanner scanner=new Scanner(System.in);
	private static final String FETCH_ALL_RECORDS="select * from training";
	//private static final String UPDATE_RECORD="update training set percentage=? where sapId=?";
	
	List<Training> allRecords=new ArrayList<Training>();
	public TrainingDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Training> displayAllRecords() {
		
		try {
			Statement stat=connection.createStatement();
			ResultSet res=stat.executeQuery(FETCH_ALL_RECORDS);
			while(res.next()) {
				Training data=new Training();
				data.setSapId(res.getInt(1));
				data.setEmployeeName(res.getString(2));
				data.setStream(res.getString(3));
				data.setPercentage(res.getInt(4));
				allRecords.add(data);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return allRecords;
	}


	@Override
	public void display() {
		
		try {
			Statement stat1=connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet res=stat1.executeQuery(FETCH_ALL_RECORDS);
			int count=1;
			while(res.next()) {
				System.out.println("Enter "+count+" Percentage");
				int percentage=scanner.nextInt();
				res.updateInt(4,percentage);
				res.updateRow();
				count++;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
