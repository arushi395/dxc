package com.dxc.training.dao;

import com.dxc.training.model.User;
public interface UserDAO {
	public boolean validateUserAndPassword(User user);
}
