package com.dxc.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.dxc.training.dbcon.DBConnection;
import com.dxc.training.model.User;

public class UserDAOImpl implements UserDAO{
	Connection connection=DBConnection.getConnection();
	private static final String FETCH= "select * from username";
	public UserDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean validateUserAndPassword(User user) {
		boolean authentic=false;
		try {
			PreparedStatement stat=connection.prepareStatement(FETCH);
			ResultSet res=stat.executeQuery();
			while(res.next())
			{
				if(res.getString(1).equals(user.getUserName()) && res.getString(2).equals(user.getPassword())) {
					authentic=true;
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return authentic;
	}

}
