package com.dxc.training.client;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		UserApp app=new UserApp();
		app.launchUserApp();
	}
}
