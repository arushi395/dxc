package com.dxc.training.client;

import java.util.Scanner;

import com.dxc.training.dao.UserDAO;
import com.dxc.training.dao.UserDAOImpl;
import com.dxc.training.model.User;

public class UserApp {
	UserDAO userDAO = new UserDAOImpl();
	String username;
	String password;
	Scanner scanner=new Scanner(System.in);
	public UserApp() {
		// TODO Auto-generated constructor stub
	}
	public void launchUserApp() {
		User user=new User();
		System.out.println("Enter your Credentials:");
		System.out.println("Username:");
		username=scanner.next();
		user.setUserName(username);
		System.out.println("Password: ");
		password=scanner.next();
		user.setPassword(password);
		boolean validated=userDAO.validateUserAndPassword(user);
		if(validated) {
			System.out.println("Welcome "+username+"!, User successfully authenticated");
			TrainingApp trainingApp=new TrainingApp();
			trainingApp.launchTrainingApp();
			
		}
		else {
			System.out.println("User name cannot be authenticated");
		}
	}
}
