package com.dxc.training.client;

import java.util.Scanner;

import com.dxc.training.dao.TrainingDAO;
import com.dxc.training.dao.TrainingDAOImpl;

public class TrainingApp {
	TrainingDAO trainingDAO= new TrainingDAOImpl();
	int choice = 0;
	Scanner scanner = new Scanner(System.in);

	public TrainingApp() {
		// TODO Auto-generated constructor stub
	}

	public void launchTrainingApp() {
		while(true) {
		System.out.println("MENU");
		System.out.println("1. Display all records");
		System.out.println("2. Display Records One by One and update the percentage");
		System.out.println("3. EXIT");
		System.out.println("Please enter you choice: (1-3)");
		choice=scanner.nextInt();
	
			switch (choice) {
			case 1:
				System.out.println(trainingDAO.displayAllRecords());
				break;
			case 2:
				trainingDAO.display();
				break;
			case 3:
				System.out.println("Thanks for using the app!");
				System.exit(0);
				break;
			default:
				System.out.println("Please select option from the menu (1-3)");
			}
		}
		
	}

}
