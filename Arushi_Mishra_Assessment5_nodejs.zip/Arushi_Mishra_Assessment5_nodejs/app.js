var express=require("express")
var app=express()
var fs=require("fs")

app.set('view engine','ejs')
var fileData;
app.get("/about",function(request,response){
    fs.readFile(__dirname+'/resources/about.txt',"utf8",function(err,data){
        if(err)
            console.log(err)
        else
            //console.log(data)
            fileData=data;
    })
    response.render("about",{data: fileData})
})
app.listen(3002);
console.log("You are listening to port 3002");