import React, { Component } from 'react';

class ProductDisplay extends Component {
    
    render() {
        const {product} = this.props
        return (
            <div>
                
                <h3>
                    Product Id :  {product.productId} &nbsp; &nbsp;
                    Product Name :    {product.productName} &nbsp; &nbsp;
                    QuantityOnHand : {product.quantityOnHand} &nbsp; &nbsp;
                    Price : {product.price}</h3> 
                    
            </div>
        );
    }
}

export default ProductDisplay;

// class ProductUpdate extends Component {
//     constructor(){
//         super();
//         this.state=({
//             updateProductId:'',
//             quantity:'',
//             errors:{
//                 quantity:''
//             }
//         })
//         this.changeId=this.changeId.bind(this)
//         this.changeQuantity=this.changeQuantity.bind(this)
//         this.updateProduct=this.updateProduct.bind(this)
//         this.validateQuantiy=this.validateQuantiy.bind(this)
//     }
//     changeId(ourData){
//         ourData.preventDefault()
//         this.setState({
//             updateProductId:ourData.target.value
//         })
//     }
//     changeQuantity(ourData){
//         ourData.preventDefault()
//         this.setState({
//             quantity:ourData.target.value
//         })
//         this.validateQuantiy(this.state.quantity)
//     }
//     validateQuantiy(quantity)
//     {
//         let message
//         if(quantity<0)
            
//                 message="Quantity cannot be negative"
    
//         else if (quantity.length==0)
        
//             message="Quantity cannot be Empty"
        
//         this.setState({errors:message})
//     }
//     updateProduct(){
//         if(this.stateupdateProductId==this.props.key)
//             this.productList.quantityOnHand=this.state.quantity
//     }
    
//     render() {
//         return (
//             <div>
//                 <form onSubmit={this.updateProduct}>
//                     Product ID : <input type="text" name="updateProductId" onChange={this.changeData}/><br/>
//                     Quantity On Hand :<input type="text" name="quantity" onChange={this.changeData}/><br/>
//                     <span className='error'>{this.state.errors.quantity}</span>
//                     <input type="submit" value="UPDATE"></input>

//                 </form>
                
//             </div>
//         );
//     }
// }
