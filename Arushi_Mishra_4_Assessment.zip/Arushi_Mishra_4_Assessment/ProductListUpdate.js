import React, { Component } from 'react';
import ProductDisplay from './ProductDisplay';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDetails from './ProductDetails';
import ProductDisplayUpdate from './ProductDisplayUpdate'

class ProductListUpdate extends Component {
    constructor(props)
    {
        super(props)
        this.state=({
            productList :[
            {
                productId: 1001,
                productName: 'Watch',
                quantityOnHand: 2000,
                price: 10000
            },
            {
                productId: 1002,
                productName: 'Mouse',
                quantityOnHand: 29,
                price: 180000
            },
            {
                productId: 1003,
                productName: 'Laptop',
                quantityOnHand: 29,
                price: 122
            },
            {
                productId: 10113,
                productName: 'Presenter',
                quantityOnHand: 29,
                price: 122
            },

            {
                productId: 111003,
                productName: 'Marker',
                quantityOnHand: 29,
                price: 122
            },
        ]
            
        })
        
    }
    render() {
        const productList=this.state.productList
        return (
            <div>
                {productList.map((product, index) =>
                    <Link to={`${this.props.match.url}/`+product.productName}>
                        <ProductDisplay render={({ match }) => match={match}}
                            nn={index}
                            key={product.productId}
                            product={product}
                        ></ProductDisplay>
                    </Link>

                )}
                <ProductUpdate product={productList} key={productList.productId}></ProductUpdate>
                
                <Route path={`${this.props.match.path}/:productName`}
                    render={({ match }) => match={match}} 
                    component={ProductDetails} />
            </div>

        );
    }
}

export default ProductListUpdate;

class ProductUpdate extends Component {
    constructor(props){
        super(props);
        //const productList=this.props
        this.state=({
            updateProductId:'',
            quantity:'',
            errors:{
                quantity:''
            }
        })
        this.changeId=this.changeId.bind(this)
        this.changeQuantity=this.changeQuantity.bind(this)
        this.updateProduct=this.updateProduct.bind(this)
        this.validateQuantiy=this.validateQuantiy.bind(this)
    }
    changeId(ourData){
        ourData.preventDefault()
        this.setState({
            updateProductId:ourData.target.value
        })
    }
    changeQuantity(ourData){
        ourData.preventDefault()
        this.setState({
            quantity:ourData.target.value
        })
        this.validateQuantiy()
    }
    validateQuantiy()
    {
        let message
        if(this.state.quantity<0)            
            message="Quantity cannot be negative"
    
        else if (this.state.quantity.length==0)
            message="Quantity cannot be Empty"
        else 
            message="Quantity Successfully updated"
        this.setState({errors:message})
    }
    updateProduct(quantity,id){
        var arr = this.props.product;
        arr[id].quantityOnHand = quantity;
        //this.props.product=arr
        this.setState({product:arr})
    }
    
    render() {
        return (
            <div>
                <form onSubmit={this.updateProduct(this.state.quantity,this.state.updateProductId)}>
                    Product ID : <input type="text" name="updateProductId" onChange={this.changeData}/><br/>
                    Quantity On Hand :<input type="text" name="quantity" onChange={this.changeQuantity}/><br/>
                    <span className='error'>{this.state.errors.quantity}</span>

                    <input type="submit" value="UPDATE"></input>
                    {this.props.product.map((product, index) =>
                        <ProductDisplayUpdate render={({ match }) => match={match}}
                            nn={index}
                            key={product.productId}
                            product={product}
                        ></ProductDisplayUpdate>
                )}
            
                </form>
                
            </div>
        );
    }
}

