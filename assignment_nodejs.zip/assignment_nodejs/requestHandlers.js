function start(response,postData,files){
    console.log("Request handler 'start' was called.");
    var body = '<html>' +
        '<head>' +
        '<meta http-equiv="Content-Type" content="text/html; ' +
        'charset=UTF-8" />' +
        '</head>' +
        '<body>' +
        '<form action="/upload" method="post">' +
        '<textarea name="text" rows="20" cols="60"></textarea>' +
        '<input type="submit" value="Submit text" />' +
        '</form>' +
        '</body>' +
        '</html>';
    response.writeHead(200, { "Content-Type": "text/html" });
    response.write(body);
    response.end();
    console.log("Start called")
}
function upload(response,postData,files){
    console.log("Upload called")
    response.writeHead(200, { "Content-Type": "text/plain" });
    response.write("your data is "+postData);
    response.end()
    console.log("Your data is saved in files :")
    for(var i=0;i<files.length;i++)
            console.log(files[i])
    
}
function download(response,postData,files){
    console.log("Download called")
}
function imageUpload(response,postData,files){
    console.log("imageUpload called")
}
exports.start=start
exports.upload=upload
exports.download=download
exports.imageUpload=imageUpload