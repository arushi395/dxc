function route(pathname,handle,response,postData,files){

    if(typeof handle[pathname]=='function'){
        handle[pathname](response,postData,files);
        console.log("Routing to "+pathname)
    }
    else{
        console.log("Sorry no handlers found for : "+pathname)
    }

}
exports.route=route