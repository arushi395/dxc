var http=require("http")
var url=require("url")
var fs=require("fs")

function start(portNumber,route,handle){
    function onRequest(request,response){
        var pathname=url.parse(request.url).pathname
        var postData="";
        var files=[];
        var counter=0;
        //request.setEncoding('utf8')
        if(request.url=='/favicon.ico'){
            response.writeHead(200,{"Content-type":"image/x-icon"})
            response.end()
            return;
        }
        var myWriteStream;
        request.addListener("data",function(postDataChunk){
            myWriteStream=fs.createWriteStream(__dirname+'/file'+counter+'.txt');
            postData +=postDataChunk;
            myWriteStream.write(postDataChunk);
            console.log("chunk received")
            files.push('file'+counter+'.txt')
            //console.log("reading chunk data "+postDataChunk+"##")
            counter++;
        });
        request.addListener("end",function(){
            route(pathname,handle,response,postData,files)
        });
        
        console.log("the requested current url is "+pathname)
        
        console.log("the current url is "+pathname)
        console.log("Your data is saved in files :")
        
        //response.writeHead(200,{"Content-type":"text-html"})//200-HTTP Status code//text-html.. kind of response whic we send
        //response.write("<h1>Name :Arushi Mishra</h1>")
        //response.end()
        
        
};
var server=http.createServer(onRequest)
server.listen(portNumber);//creates the server on that port
console.log("server Started on port number : "+portNumber)
}
exports.start=start