package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

//import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.model.Product;
import com.dxc.pms.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductController {
	@Autowired
	ProductService productService;
	//get a product with the ID
	@GetMapping("/{productId}")
	public Product getProduct(@PathVariable("productId")int pId) {
		System.out.println("GetProduct  called with product Id : "+pId);
		return productService.getProduct(pId);
	}
	//to get all products
	@GetMapping
	public List<Product> getAllProducts(){
		System.out.println("Fetching all products ");
		return productService.getProducts();
	}
	// to delete a product with Id
	@DeleteMapping("/{productId}")
	public boolean deleteProduct(@PathVariable("productId")int pId) {
		System.out.println("deleting product with product Id : "+pId);
		return productService.deleteProduct(pId);
	}
	//to save a product
	@PostMapping()
	public boolean saveProduct(@RequestBody Product product) {
		System.out.println("Save product called");
		System.out.println(product);
		return productService.addProduct(product);
	}
	@PutMapping()
	public boolean updateProduct(@RequestBody Product product) {
		System.out.println("update product called");
		System.out.println(product);
		return productService.updateProduct(product); 
	}
	
//	@RequestMapping("/getProduct/{productId}/orders/{orderId}")
//	public Product getProduct2(@PathVariable("productId")int pId,@PathVariable("orderId")int orderId) {
//		System.out.println("GetProduct 2 called with product Id : "+pId+" And order Id : "+ orderId);
//		return productService.getProduct(12);
//	}
//	@RequestMapping("/getProduct/pp")
//	public Product getProduct3() {
//		System.out.println("GetProduct 3 called ");
//		return productService.getProduct(12);
//		
//	}
//	@RequestMapping("/getProduct")
//	public Product getProduct() {
//		System.out.println("getProduct without parameter called");
//		return productService.getProduct(12);
//	}
//	@RequestMapping("/productSave")
//	public ModelAndView productSave(Product product) {
//		System.out.println("Product in controller: "+product);
//		productService.addProduct(product);
//		
//		return new ModelAndView("success","p",product);
//	}
	

}
