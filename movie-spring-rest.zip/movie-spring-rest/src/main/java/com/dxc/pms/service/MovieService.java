package com.dxc.pms.service;

import java.util.List;

import com.dxc.pms.model.Movie;

public interface MovieService {
	public Movie getMovieByID(int movieId);
	public boolean updateMovie(Movie movie);
	public boolean addMovie(Movie movie);
	public boolean deleteMovie(int movieId);
	public List<Movie> getAllMovies();
	public boolean isExists(int movieId);

}
