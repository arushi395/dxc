package com.dxc.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.pms.model.Movie;
import com.dxc.pms.service.MovieService;

@RestController
@RequestMapping("/movie")
public class MovieController {
	@Autowired
	MovieService movieService;
	@GetMapping
	public List<Movie> getAllMovies(){
		return movieService.getAllMovies();
	}
	@GetMapping("/{movieId}")
	public Movie getMovie(@PathVariable("movieId")int movieId) {
		if(movieService.isExists(movieId))
			return movieService.getMovieByID(movieId);
		else 
			return null;
	}
	@PostMapping()
	public boolean addMovie(@RequestBody Movie movie) {
		if(movieService.isExists(movie.getMovieId())) {
			System.out.println("Movie already exists in database");
		return false;}
		else
			return movieService.addMovie(movie);
		
	}
	@DeleteMapping("/{movieId}")
	public boolean deleteMovie(@PathVariable("movieId")int movieId) {
		if(movieService.isExists(movieId))
			return movieService.deleteMovie(movieId);
		else 
			return false;
	}
	@PutMapping()
	public boolean updateMovie(@RequestBody Movie movie) {
		if(movieService.isExists(movie.getMovieId())) {
			System.out.println("Movie exists in database and is updated");
		return movieService.updateMovie(movie);}
		else
			return false;
	}

}
