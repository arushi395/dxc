import axios from 'axios'
const PRODUCT_API_URL='http://localhost:8003/product'
//const PRODUCT_API_URL='http://10.231.137.33:8013/product'
class ProductDataService
{
    getAllProducts()
    {
        return axios.get(`${PRODUCT_API_URL}`);
    }
    deleteProduct(productId)
    {
        return axios.delete(`${PRODUCT_API_URL}/${productId}`);
    }
    getProduct(productId)
    {
        return axios.get(`${PRODUCT_API_URL}/${productId}`);
    }
    updateProduct(product)
    {
        return axios.put(`${PRODUCT_API_URL}/`,product);
    }
    addProduct(product)
    {
        return axios.post(`${PRODUCT_API_URL}/`,product);
    }
    getProductByName(productName)
    {
        return axios.get(`${PRODUCT_API_URL}/searchProduct/${productName}`);
    }


}
export default new ProductDataService()