import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService'
import { Formik, Form, Field, ErrorMessage } from 'formik';
class ProductComponent extends Component {
    constructor(props){
        super(props)
        this.state=({
            productId : this.props.match.params.prodId,
            productName:'',
            quantityOnHand:'',
            price:'',
            btnText:'ADD',
            errMsg:''            
        })
        this.onSubmit1=this.onSubmit1.bind(this)
    }
    componentWillMount(){
        if(!this.state.productId){
            return;}
        
        ProductDataService.getProduct(this.state.productId).then(
            response=>{
                this.setState({
                    productName: response.data.productName,
                    quantityOnHand: response.data.quantityOnHand,
                    price: response.data.price,
                    btnText:'Update'
                }); 
            })
    }
    onSubmit1(product){
        console.log(product);
        if(this.state.productId){
            ProductDataService.updateProduct(product).then(response =>{this.props.history.push("/products");
            //this.setState({errMsg:response.status})
        });}
        else{
            ProductDataService.addProduct(product).then(response =>{this.props.history.push("/products");
            //this.setState({errMsg:response.status})
        });}
        
    }
    validateProductForm(values){
        let errors={}
        if(!values.productName){
            errors.productName="Enter Product Name"
        }
        else if(!values.quantityOnHand){
            errors.quantityOnHand="Enter Quantity"
        }
        else if(!values.price){
            errors.price="Enter Price"
        }
        else if(values.price<0){
            errors.price="Price cannot be negative"
        }
        
        else if(values.quantityOnHand<0){
            errors.quantityOnHand="Quantity cannot be negative"
        }
        else if(values.productName.length<3){
            errors.productName="Invalid product name, length should be more than 3"
        }
        return errors;
    }
    render() {
        let {productId,productName,quantityOnHand,price}= this.state;
        let add=this.state.productId;
        // let btnText;
        // let bool;
        // if(add){
        //      btnText="Save";
        //      bool="true";}
        // else{
        //      btnText="Add";
        //      bool="false";
        // }
        return (
            <div>
                <h3>ADD/UPDATE PRODUCT</h3>
                
                {/* <div>{productId}</div>
                <div>{productName}</div>
                <div>{quantityOnHand}</div>
                <div>{price}</div> */}
                <div className="container">
                <Formik initialValues={{productId,productName,quantityOnHand,price}} enableReinitialize={true} 
                onSubmit={this.onSubmit1} validateOnChange={false} validateOnBlur={false} validate={this.validateProductForm}>
                    <Form>
                        <ErrorMessage name="productName" component="div" className="alert alert-warning"/>
                        <ErrorMessage name="quantityOnHand" component="div" className="alert alert-warning"/>
                        <ErrorMessage name="price" component="div" className="alert alert-warning"/>
                        {!add?<fieldset className="form-group">
                            <label>Product Id</label>
                            <Field className="form-control" type="text" name="productId"  ></Field>
                        </fieldset>:
                        <fieldset className="form-group">
                            <label>Product Id</label>
                            <Field className="form-control" type="text" name="productId" disabled ></Field>
                        </fieldset>}
                        <fieldset className="form-group">
                            <label>Product Name</label>
                            <Field className="form-control" type="text" name="productName" ></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Quantity On Hand</label>
                            <Field className="form-control" type="text" name="quantityOnHand" ></Field>
                        </fieldset>
                        <fieldset className="form-group">
                            <label>Price</label>
                            <Field className="form-control" type="text" name="price" ></Field>
                        </fieldset>
                        <button className="btn btn-success" type="submit">{this.state.btnText}</button>
                    </Form>
                </Formik>
                </div>
            </div>
        );
    }
}

export default ProductComponent;