import React, { Component } from 'react';
import ProductDataService from '../service/ProductDataService';

class ListProductComponent extends Component {
    constructor(props){
        super(props);
        this.state=({
            product:[],
            message:'',
            pName:this.props.match.params.prodName,
            msg:''
        })
        this.refreshProduct=this.refreshProduct.bind(this);
        this.deleteButtonClicked=this.deleteButtonClicked.bind(this);
        this.updateProductClicked=this.updateProductClicked.bind(this);
        this.addProductClicked=this.addProductClicked.bind(this);
        this.searchProductClicked=this.searchProductClicked.bind(this);
    }
    componentWillMount(){
        this.refreshProduct()
    }
    refreshProduct(){
        
        if(this.state.pName==null){
            ProductDataService.getAllProducts().then(
                response=>{
                    console.log(response.data);
                    this.setState({product:response.data});
        })
        }
        else{
            ProductDataService.getProductByName(this.state.pName).then(
            response=>{
                
                console.log(response.data);
                this.setState({product:response.data});
            })
            }
    }
    deleteButtonClicked(productIdToDelete){
        ProductDataService.deleteProduct(productIdToDelete).then(
            response=>{this.setState({
                message:'Product with Id : '+productIdToDelete+' deleted successfully'
            })
            this.refreshProduct()

            }
        );
        this.refreshProduct()
    }
    updateProductClicked(productId){
        this.props.history.push(`/products/${productId}`)
    }
    addProductClicked(){
        this.props.history.push(`/addProduct`)
    }
    searchProductClicked(){
        this.props.history.push('/searchProduct')
    }
    render() {
        let msg='';
        if(this.state.product.length===0){
            msg="Sorry, no products are  available"
        }
        return (
            <div className="container">
                {this.state.message && <div className="alert alert-danger">{this.state.message}</div>}
                
                <h2>All Products</h2>
                {msg==='' ?
                <div className="container">
                    <table className="table">
                        
                        <thead>
                            <tr>
                            <th>Product Id</th>
                            <th>Product Name</th>
                            <th>Quantity On Hand</th>
                            <th>Price</th>
                            <th>Update</th>
                            <th>Delete</th>
                            
                            </tr>
                        </thead>
                      
                        <tbody>
                            {
                                this.state.product.map(product =>
                                    <tr key={product.productId}>
                                        <td>{product.productId}</td>
                                        <td>{product.productName}</td>
                                        <td>{product.quantityOnHand}</td>
                                        <td>{product.price}</td>
                                        <td><button className="btn btn-warning" onClick={()=> this.updateProductClicked(product.productId)}>Update</button></td>
                                        <td><button className="btn btn-danger" onClick={()=> this.deleteButtonClicked(product.productId)}>Delete</button></td>
                                        
                                    </tr>                                                           
                                    )
                            }
                        </tbody>
                        
                    </table>
                    <button className="btn btn-success" onClick={()=> this.addProductClicked()}>Add Product</button>{'   '}
                    <button className="btn btn-success" onClick={()=> this.searchProductClicked()}> SearchByName</button>
                </div>:
                    <div>{msg}<br/>
                    <button className="btn btn-success" onClick={()=> this.addProductClicked()}>Add Product</button></div>}
            </div>
        );
    }
}

export default ListProductComponent;