import React, { Component } from 'react';
import { Formik, Form,Field } from 'formik';
// import ProductDataService from '../service/ProductDataService';

class SearchProductComponent extends Component {
    constructor(props){
        super(props)
        this.state=({
            productName:"",
        })
        this.submit=this.submit.bind(this);
    }
    submit(values){
        console.log(values.productName);
        this.props.history.push(`/allproducts/${values.productName}`);

    }
    render() {
        let {productName}=this.state
        return (
            <div>
                <div className="Container">
                    <Formik initialValues={{productName}} enableReinitialize={true} onSubmit={this.submit}>
                        <Form>
                        <fieldset className="form-group">
                            <label>Product Name</label>
                            <Field className="form-control" type="text" name="productName"  ></Field>
                        </fieldset>
                        <button className="btn btn-success" type="submit">Search</button>
                        </Form>
                    </Formik>
                </div>
            </div>
        );
    }
}

export default SearchProductComponent;