import React, { Component } from 'react';
import ListProductComponent from './component/ListProductComponent';
import {Switch,Route} from 'react-router-dom';
import {BrowserRouter as Router} from 'react-router-dom';
import './App.css';
import ProductComponent from './component/ProductComponent';
import SearchProductComponent from './component/SearchProductComponent';
//import 'bootstrap/dist/css/bootstrap.css';

class App extends Component {
  render() {
    return (
      <div>
        <h1 className="App"> MY PRODUCT APP</h1>
        <Router>
          <Switch>
          <Route exact path="/" component={ListProductComponent}/>
          <Route exact path="/products" component={ListProductComponent}/>
          <Route exact path="/allproducts/:prodName" component={ListProductComponent}/>
          <Route exact path="/products/:prodId" component={ProductComponent}/>
          <Route exact path="/addProduct" component={ProductComponent}/>
          <Route exact path="/searchProduct" component={SearchProductComponent}/>

          </Switch>
        </Router>
        {/* <ListProductComponent></ListProductComponent> */}
      </div>
    );
  }
}

export default App;

// import React from 'react';
// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;
