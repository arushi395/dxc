package com.dxc.pms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/login")
	public ModelAndView gg(){
		String m="Lets go home";
		ModelAndView view =new ModelAndView();
		view.setViewName("chennai");
		view.addObject("msg",m);
		return view;
	}
	
	@RequestMapping("/signUp")
	public String gaag(){
		return "sign";
	}
}