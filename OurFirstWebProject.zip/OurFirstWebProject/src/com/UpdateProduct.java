package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.dao.ProductDAOImpl;
import com.dxc.pms.model.Product;

/**
 * Servlet implementation class UpdateProduct
 */
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int productId=Integer.parseInt(request.getParameter("updateProductId"));
		String productName=request.getParameter("updateProductName");
		int quantityOnHand=Integer.parseInt(request.getParameter("updateProductQuantity"));
		int price=Integer.parseInt(request.getParameter("updateProductPrice"));
		Product product=new Product(productId, productName, quantityOnHand, price);
		ProductDAO productDAO=new ProductDAOImpl();
		boolean isExists=productDAO.isProductExists(productId);
		if(isExists==true) {
			productDAO.updateProduct(product);
			response.getWriter().println("<h1>Product with id "+productId+" updated successfully </h1>");
			response.getWriter().println("</br><a href='Welcome'>Home</a>");
		}
		else {
			response.getWriter().println("<h1>Product does not exist. Enter valid ID.</h1>");
			response.getWriter().println("</br><a href='updateProduct.html'>Update Product By Id</a>");
			response.getWriter().println("</br><a href='Welcome'>Home</a>");
		}
			
	}

}
