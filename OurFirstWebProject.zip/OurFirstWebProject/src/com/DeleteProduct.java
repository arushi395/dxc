package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.dao.ProductDAOImpl;
import com.dxc.pms.model.Product;

/**
 * Servlet implementation class DeleteProduct
 */
public class DeleteProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteProduct() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id=Integer.parseInt(request.getParameter("deleteProduct"));
		
		ProductDAO productDAO=new ProductDAOImpl();
		boolean isExists=productDAO.isProductExists(id);
		if(isExists==true) {
			productDAO.deleteProduct(id);
			response.getWriter().println("<h1>Product with id :"+id+" deleted successfully </h1>");
			response.getWriter().println("</br><a href='Welcome'>Home</a>");
		}
		else {
			response.getWriter().println("<h1>Product does not exists. </h1>");
			response.getWriter().println("</br><a href='deleteProduct.html'>Search Again</a>");
			response.getWriter().println("</br><a href='Welcome'>Home</a>");
		}
	}

}
