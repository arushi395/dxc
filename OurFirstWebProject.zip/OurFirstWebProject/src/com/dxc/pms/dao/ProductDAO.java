package com.dxc.pms.dao;

import com.dxc.pms.model.Product;

import java.util.List;
public interface ProductDAO {
	public Product getProduct(int productId);
	public List<Product> getAllProduct();
	public void addProduct(Product product);
	public void deleteProduct(int productId);
	public void updateProduct(Product product);
	public boolean isProductExists(int productId);

}
