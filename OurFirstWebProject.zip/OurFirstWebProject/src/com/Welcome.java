package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcome
 */
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Welcome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
    int counter=0;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		counter++;
		String uname=request.getParameter("username");
		response.getWriter().println("<h1>Welcome to DXC, "+uname+"</h1>");
		response.getWriter().println("<h1>You are user number : "+counter+"</h1>");
		response.getWriter().println("<a href='productForm.html'>Add Product</a></br>");
		response.getWriter().println("<a href='productSearch.html'>Get Product by ID</a></br>");
		response.getWriter().println("<a href='ShowAll'>Get all products</a></br>");
		response.getWriter().println("<a href='deleteProduct.html'>Delete Product by ID</a></br>");
		response.getWriter().println("<a href='updateProduct.html'>Update Product by ID</a></br>");
		response.getWriter().println("<a href='tc.html'>T&C</a>");
	}

}
