package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CheckServlet
 */
public class CheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	int count,marks;
    @Override
    public void init() throws ServletException {
    	// TODO Auto-generated method stub
    	count= 0;
    	marks=0;
    }
	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String answer=request.getParameter("answer");
		System.out.println(answer);
		HttpSession session=request.getSession();
		String correctAnswer = request.getParameter("correctAnswer");
		System.out.println(correctAnswer);
		
		
		if(answer==null) {
			RequestDispatcher dispatch= request.getRequestDispatcher("firstquestion.jsp");
			dispatch.forward(request, response);
		}
		else {
			
			if(correctAnswer.equalsIgnoreCase(answer)) {
				marks=marks+10;
			}
			count++;
			if(count==1)
			{ 					 
				RequestDispatcher dispatch= request.getRequestDispatcher("question.jsp");
				dispatch.forward(request, response);
				
			}
			else if(count==2)
			{
				if(correctAnswer.equalsIgnoreCase(answer)) {
					 response.getWriter().println("correct"); }
				else {
					 response.getWriter().println("incorrect"); }
				RequestDispatcher dispatch= request.getRequestDispatcher("lastquestion.jsp");
				dispatch.forward(request, response);
			}
			else if(count==3)
			{
				session.setAttribute("totalMarks", marks);
				RequestDispatcher dispatch= request.getRequestDispatcher("marks.jsp");
				dispatch.forward(request, response);
			}
			
		}
		
		
		
		
	}

}
